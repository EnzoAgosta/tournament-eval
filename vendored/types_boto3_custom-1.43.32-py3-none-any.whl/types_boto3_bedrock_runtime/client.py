"""
Type annotations for bedrock-runtime service Client.

[Documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from boto3.session import Session
    from types_boto3_bedrock_runtime.client import BedrockRuntimeClient

    session = Session()
    client: BedrockRuntimeClient = session.client("bedrock-runtime")
    ```
"""

from __future__ import annotations

import sys
from collections.abc import Mapping
from typing import Any

from botocore.client import BaseClient, ClientMeta
from botocore.errorfactory import BaseClientExceptions
from botocore.exceptions import ClientError as BotocoreClientError

from .paginator import ListAsyncInvokesPaginator
from .type_defs import (
    ApplyGuardrailRequestTypeDef,
    ApplyGuardrailResponseTypeDef,
    ConverseRequestTypeDef,
    ConverseResponseTypeDef,
    ConverseStreamRequestTypeDef,
    ConverseStreamResponseTypeDef,
    CountTokensRequestTypeDef,
    CountTokensResponseTypeDef,
    GetAsyncInvokeRequestTypeDef,
    GetAsyncInvokeResponseTypeDef,
    InvokeGuardrailChecksRequestTypeDef,
    InvokeGuardrailChecksResponseTypeDef,
    InvokeModelRequestTypeDef,
    InvokeModelResponseTypeDef,
    InvokeModelWithBidirectionalStreamRequestTypeDef,
    InvokeModelWithBidirectionalStreamResponseTypeDef,
    InvokeModelWithResponseStreamRequestTypeDef,
    InvokeModelWithResponseStreamResponseTypeDef,
    ListAsyncInvokesRequestTypeDef,
    ListAsyncInvokesResponseTypeDef,
    StartAsyncInvokeRequestTypeDef,
    StartAsyncInvokeResponseTypeDef,
)

if sys.version_info >= (3, 12):
    from typing import Literal, Unpack
else:
    from typing_extensions import Literal, Unpack


__all__ = ("BedrockRuntimeClient",)


class Exceptions(BaseClientExceptions):
    AccessDeniedException: type[BotocoreClientError]
    ClientError: type[BotocoreClientError]
    ConflictException: type[BotocoreClientError]
    InternalServerException: type[BotocoreClientError]
    ModelErrorException: type[BotocoreClientError]
    ModelNotReadyException: type[BotocoreClientError]
    ModelStreamErrorException: type[BotocoreClientError]
    ModelTimeoutException: type[BotocoreClientError]
    ResourceNotFoundException: type[BotocoreClientError]
    ServiceQuotaExceededException: type[BotocoreClientError]
    ServiceUnavailableException: type[BotocoreClientError]
    ThrottlingException: type[BotocoreClientError]
    ValidationException: type[BotocoreClientError]


class BedrockRuntimeClient(BaseClient):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime.html#BedrockRuntime.Client)
    [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/)
    """

    meta: ClientMeta

    @property
    def exceptions(self) -> Exceptions:
        """
        BedrockRuntimeClient exceptions.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime.html#BedrockRuntime.Client)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#exceptions)
        """

    def can_paginate(self, operation_name: str) -> bool:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/can_paginate.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#can_paginate)
        """

    def generate_presigned_url(
        self,
        ClientMethod: str,
        Params: Mapping[str, Any] = ...,
        ExpiresIn: int = 3600,
        HttpMethod: str = ...,
    ) -> str:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/generate_presigned_url.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#generate_presigned_url)
        """

    def apply_guardrail(
        self, **kwargs: Unpack[ApplyGuardrailRequestTypeDef]
    ) -> ApplyGuardrailResponseTypeDef:
        """
        The action to apply a guardrail.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/apply_guardrail.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#apply_guardrail)
        """

    def converse(self, **kwargs: Unpack[ConverseRequestTypeDef]) -> ConverseResponseTypeDef:
        """
        Sends messages to the specified Amazon Bedrock model.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/converse.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#converse)
        """

    def converse_stream(
        self, **kwargs: Unpack[ConverseStreamRequestTypeDef]
    ) -> ConverseStreamResponseTypeDef:
        """
        Sends messages to the specified Amazon Bedrock model and returns the response
        in a stream.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/converse_stream.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#converse_stream)
        """

    def count_tokens(
        self, **kwargs: Unpack[CountTokensRequestTypeDef]
    ) -> CountTokensResponseTypeDef:
        """
        Returns the token count for a given inference request.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/count_tokens.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#count_tokens)
        """

    def get_async_invoke(
        self, **kwargs: Unpack[GetAsyncInvokeRequestTypeDef]
    ) -> GetAsyncInvokeResponseTypeDef:
        """
        Retrieve information about an asynchronous invocation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/get_async_invoke.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#get_async_invoke)
        """

    def invoke_guardrail_checks(
        self, **kwargs: Unpack[InvokeGuardrailChecksRequestTypeDef]
    ) -> InvokeGuardrailChecksResponseTypeDef:
        """
        Evaluates messages against inline guardrail checks.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/invoke_guardrail_checks.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#invoke_guardrail_checks)
        """

    def invoke_model(
        self, **kwargs: Unpack[InvokeModelRequestTypeDef]
    ) -> InvokeModelResponseTypeDef:
        """
        Invokes the specified Amazon Bedrock model to run inference using the prompt
        and inference parameters provided in the request body.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/invoke_model.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#invoke_model)
        """

    def invoke_model_with_bidirectional_stream(
        self, **kwargs: Unpack[InvokeModelWithBidirectionalStreamRequestTypeDef]
    ) -> InvokeModelWithBidirectionalStreamResponseTypeDef:
        """
        Invoke the specified Amazon Bedrock model to run inference using the
        bidirectional stream.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/invoke_model_with_bidirectional_stream.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#invoke_model_with_bidirectional_stream)
        """

    def invoke_model_with_response_stream(
        self, **kwargs: Unpack[InvokeModelWithResponseStreamRequestTypeDef]
    ) -> InvokeModelWithResponseStreamResponseTypeDef:
        """
        Invoke the specified Amazon Bedrock model to run inference using the prompt and
        inference parameters provided in the request body.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/invoke_model_with_response_stream.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#invoke_model_with_response_stream)
        """

    def list_async_invokes(
        self, **kwargs: Unpack[ListAsyncInvokesRequestTypeDef]
    ) -> ListAsyncInvokesResponseTypeDef:
        """
        Lists asynchronous invocations.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/list_async_invokes.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#list_async_invokes)
        """

    def start_async_invoke(
        self, **kwargs: Unpack[StartAsyncInvokeRequestTypeDef]
    ) -> StartAsyncInvokeResponseTypeDef:
        """
        Starts an asynchronous invocation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/start_async_invoke.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#start_async_invoke)
        """

    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_async_invokes"]
    ) -> ListAsyncInvokesPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/get_paginator.html)
        [Show types-boto3-custom documentation](https://youtype.github.io/types_boto3_docs/types_boto3_bedrock_runtime/client/#get_paginator)
        """
